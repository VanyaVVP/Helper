# Группы {{title}}

## Карточка
|                         |              |
|:-----------------------:|:------------:|
|    **Идентификатор**    |   *{{id}}*   |
|    **Наименование**     |  {{title}}   |
| **Родительская группа** |  {{parent}}  |
|     **Комментарий**     | {{comments}} |

## Автоматизированные системы
![Автоматизированные системы](@entity/kadzo.v2023.systems/systems_by_group?group_id={{id}})

## Контекст (текущий) 
![Контекст(as-is)](@entity/kadzo.v2023.group_context/group_context_asis?group={{id}})

## Контекст целевой (текущий) 
![Контекст(as-is)](@entity/kadzo.v2023.group_context/group_context_tobe?group={{id}})