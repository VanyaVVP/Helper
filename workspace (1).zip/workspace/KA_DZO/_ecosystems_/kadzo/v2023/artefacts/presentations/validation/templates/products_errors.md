# Ошибки "Продуктов или услуг"

{{#general}}
## Базовые атрибуты
Ошибки в атрибуте "Наименование", "Описание" и "Статус" (title, description, status)
![Загрузка ошибок](@entity/kadzo.v2023.products/validation.base_attrib?domain={{domain}})
{{/general}}


{{^iserrors}}
**Продакт YouTube тихо плачет в сторонке** :D

Ты делаешь нас счастливыми. 

Может быть подарим тебе футболку, но это не точно.

{{/iserrors}}