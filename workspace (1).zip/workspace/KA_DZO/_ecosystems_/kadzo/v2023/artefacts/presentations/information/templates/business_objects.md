# Бизнес объект {{title}}

## Карточка
|                                       |                    |
|:-------------------------------------:|:------------------:|
|           **Идентификатор**           |      *{{id}}*      |
|             **Описание**              |     {{title}}      |
|              **Статус**               |     {{status}}     |
|            **Комментарий**            | {{comments}}       |


## Объекты данных
![Объекты_данных](@entity/kadzo.v2023.data_objects/data_objects_by_business?business_object_id={{id}})

## Бизнес-процессы, оперирующие бизнес-объектом
![Бизнес-процессы](@entity/kadzo.v2023.processes/processes_by_business_objects?business_object={{id}})
