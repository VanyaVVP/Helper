# Hello

| Код | Наименование |
|-----|--------------|
{{#.}}
| [{{code}}](/entities/kadzo/3_6_item?index={{index}}) | {{name}}
{{/.}}